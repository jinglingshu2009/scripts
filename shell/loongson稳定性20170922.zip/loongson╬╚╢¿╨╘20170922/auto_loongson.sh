#!/bin/bash
#Auto test longson file_sync tcp udp by likun on 2017-08-14
#测试龙芯平坦单闸外置文件同步
_add_ip ( ) {  #添加IP地址
A=192 B=168  NIC_default=1 #A.B.C.D
 if [ ! $1 ]; then #判断网卡是否存在
    echo "ip [NIC error!]"
    exit
  elif [ ! $2 ];then #判断IP地址中C是否存在
    echo "ip NIC [C_list error!]"
    exit
  elif [ ! $3 ];then #判断IP地址中D是否存在
    echo "ip NIC C_list [D_list error!]"
    exit
    fi
    for ((C_list=1;C_list<=$2;C_list++))
        do
        echo "ifconfig $1:$NIC_default $A.$B.$C_list.$3/24"
        #ifconfig $1:$NIC_default $A.$B.$C_list.$3/24
        NIC_default=$(($NIC_default+1)) 
     done
}

check_file () {
	# for (($loop;loop<=$run_number;loop++))
	# do
	if [ ! $1 ];then
		echo "check_file  1=dst_dir/src_dir 2=AA/BB"
		exit
	fi
	Dele_file_number=$((`ls -rtl $1/*|wc -l`/2))	#Default Delete 1/2 file 
	file_list=`ls -rtl $1/*|awk '{print $NF}'|head -$Dele_file_number`	#$1=Desttination directory BB 
case $2 in
	AA)
	   for list in $file_list
	    do
			rm -rf $list
			echo "`date +%F====%T`	$list	Delete	ok!!!" 
		done
	;;
	BB)
	   for list in $file_list
	    do
		   dst_file=`basename $list`  	 #获取文件列表中的文件名称
		   dst_file_dir=`dirname $list`  #获取文件列表中的文件路径
		   #echo "2" >>$list
		   if [ "$check_md5" == "on" ];then #判断是否开启文件MD5检验
			   src_md5=`echo $list|awk -F. '{print $1}'|awk -F- '{print $2}'`
			   dst_md5=`md5sum $list|awk '{print $1}'`
		   #echo id=$n file=$list$ src_md5=$src_md5  dst_md5=$dst_md5 
			   if [ $src_md5 == $dst_md5 ];then
				   rm -rf $list
				   echo "`date +%F====%T`	$list	Delete	ok!!!" 
				 else
				   echo "`date +%F====%T`	$list	Error	!!!" 
			   fi
			else 
				rm -rf $list
				echo "`date +%F====%T`	$list	Delete	ok!!!" 
			fi
	   done
    ;;
    *)
		echo "check_file  1=dst_dir/src_dir  3=AA/BB"
	;;
esac
	# done
	#basename=get filename ;dirname=get dirname
}

ping_ck( ) {
 case $1 in
          p1)
                ping -c $2 $3 >/dev/null
                if [ $? = 0 ];then
                           return 0
                   else
                           return 1
                   fi
                   ;;
      p2)
          ping -c $2 $3 |grep packets >.ping2
          p_check=`cat .ping2 | awk '{print $1}'`
          p_check2=`cat .ping2 | awk '{print $4}'` && rm .ping2 -rf 
         # echo 1:$p_check2 2:$2
                if [ $p_check2 = $2 ];then
                           return 3
                   else
                           return 4
                   fi
                   ;;
                *)
                echo "#ping_ck p1/p2 ping_number ip; 0=ping success 1=ping nowhere  3=Accurate normal ping packets 4=Precise ping packet loss "
        esac
}


stability_test ( ) { #外置文件同步可靠性测试
case  $1 in
	add) #添加配置
	case $2 in
		send_conf) #设置发送端(1)配置
				sh Tmp_fsync.sh add_Tmp_fsync 2>&1  >>/dev/null #安装发送/接收客户端软件
				#echo $2
				_add_ip eth0 $run_number 1 #ip NIC C D {192.168.C.D}
				 default_config=$default_send_conf
        	      for ((loop=1;loop<=$run_number;loop++));
					do
						if [ ! -x "$senddir$loop" ]; then #判断文件夹是否存在
				    	  mkdir  -p $senddir$loop
				          _send_file_dir=$senddir$loop/`echo $2|awk -F_ '{print $1}'`_file
						  _send_config="$senddir$loop/filesync.conf"
						  _send_log="$senddir$loop"
						  mkdir  -p $_send_file_dir && cp $default_soft $senddir$loop/fsync-lin
						#sed -i '2a drink tea' /etc/passwd  #在第二行之后插入‘drink tea’
						#sed -i 's/cyber=xxr/cyber=xx/g' log #替换文本中cyber=xxr为cyber=xx
						#sed -i '4d' log  #删除第四行				
						#sed -i '$d' log   #删除最后一行
						#[system]系统配置
						sed -e '/^mode=/cmode=send' $default_config |tr -d '\r'  >$_send_config #替换指定行内容(mode=send) 
						sed -i '/^backlist=/cbacklist=1' $_send_config |tr -d '\r' #替指backlist内容(0不保存列表；1保存文件列表) 
						sed -i '/^service=/cservice=send'$loop'' $_send_config |tr -d '\r' #替指service内容
						#[authority]认证配置
						#[log]日志配置
						_start=`grep -rn "path" $_send_config|sed -n 1p |awk -F: '{print $1}'|tr -d '\r'`
						sed -i ''$_start'c\path='$_send_log''  $_send_config |tr -d '\r' #替换log中path行内容(path=$senddir$loop) 
						#[task]任务配置
						sed -i '/^id=/cid='$loop''  $_send_config |tr -d '\r' #替指id内容(id=$loop) 
						sed -i '/^desc=/cdesc=send-task-'$loop''  $_send_config |tr -d '\r' #替指desc内容(desc=send-task-$loop) 
						sed -i '/^ip=/cip=192.168.'$loop'.2'  $_send_config |tr -d '\r' #替换ip行内容(ip=192.168.$loop.2) 
						sed -i '/^port=/cport='$(($loop+16100))''  $_send_config |tr -d '\r' #替换指port内容(port=161$loop) 
						sed -i '/^synctype=/csynctype=del'  $_send_config |tr -d '\r' #替换synctype内容(synctype=copy|del) 
						_start=`grep -rn "path" $_send_config|sed -n 2p |awk -F: '{print $1}'|tr -d '\r'`
						sed -i ''$_start'c\path='$_send_file_dir''  $_send_config |tr -d '\r' #替换task中path行内容(path=$senddir$loop/send_file) 
						fi
					done 
			;;
		gap_conf)
			sh Tmp_fsync.sh add_Tmp_fsync 2>&1  >>/dev/null #安装发送/接收客户端软件
			#echo $2
			for ((loop=1;loop<=$run_number;loop++));
			do
				_file_port=$(($loop+16100))
				default_ping=15
				while [ 1 ]
				do
					ping_ck p2 $default_ping $default_gapa_ip 2>&1 >>/dev/null 
					_pa=$?  #检查连接设备内网是否正常：$?=3表示正常,4表示错误
					ping_ck p2 $default_ping $default_gapb_ip 2>&1 >>/dev/null 
					_pb=$?  #检查连接设备外网是否正常：$?=3表示正常,4表示错误
					_sum=$(($_pa+$_pb))
					if [ "$_sum" == "6" ];then
						break
					fi
				done
				_id=1 && id=1
					echo "#######################正在配置第$loop台设备###########################"
				until (( $_id > 2 ))
				do
					#unset _license_ _license_old  _check_id up_dir_disk local_tmp_disk name
					
					if [ $_id = 1 ];then
						_check_id=3p
						default_ip=$default_gapa_ip	
						up_dir_disk="/usr/gap/etc/filesync/task_a.conf"
						local_tmp_disk="/tmp/task_a.conf"
						name=gapa_conf
						_ip_d=2
						#代理配置send（100.100:16200）======>gapa(100.200:16200)----gapb(100.100:16200)======>recv(100.200:16200)
						_task_tcp=$(($loop+100)) && _task_udp=$(($loop+200))
						_sproxy_port=16200
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "echo \[default\] >/usr/gap/etc/net/ip.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/default/a\\eth1 	192.168.100.200 	255.255.255.0' /usr/gap/etc/net/ip.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_tcp' 	192.168.100.200 	$_sproxy_port 	1000' /usr/gap/etc/tcp/sproxy.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_tcp' 	tcp 	0' /usr/gap/etc/disk/task.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_udp' 	192.168.100.200 	$_sproxy_port' /usr/gap/etc/udp/sproxy.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_udp' 	udp 	0' /usr/gap/etc/disk/task.conf" 2>&1 >>/dev/null
						
					elif [ $_id = 2 ];then
						_check_id=4p
						default_ip=$default_gapb_ip
						up_dir_disk="/usr/gap/etc/filesync/task_b.conf"
						local_tmp_disk="/tmp/task_b.conf"
						name=gapb_conf
						_ip_d=4
						#代理配置send（100.100:16100）======>gapa(100.200:16100)----gapb(100.100:16100)======>recv(100.200:16100)
						_task_tcp=$(($loop+100)) && _task_udp=$(($loop+200))
						_sproxy_port=16200
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "echo \[default\] >/usr/gap/etc/net/ip.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/default/a\\eth1 	192.168.100.100 	255.255.255.0' /usr/gap/etc/net/ip.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_tcp' 	192.168.100.200 	$_sproxy_port 	10240' /usr/gap/etc/tcp/cproxy.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_tcp' 	tcp 	10240' /usr/gap/etc/disk/task.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_udp' 	192.168.100.200 	$_sproxy_port 	10240' /usr/gap/etc/udp/cproxy.conf" 2>&1 >>/dev/null
						sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$_task_udp' 	udp 	10240' /usr/gap/etc/disk/task.conf" 2>&1 >>/dev/null
					fi
					sh auto_ssh.sh scp_down $default_ip $default_gapa_passwd /storage/cyber/etc/webadmin/license /tmp/.license
					if [ ! -f "/tmp/.license" ];then
						echo "id=$loop=$_id 获取license文件失败!"
							_id=$(($_id+1))
				   else
						_license_=`cat /tmp/.license |sed -n  $_check_id`	&& rm -rf /tmp/.license
						if [ ! -f "/tmp/._license_" ];then
							touch 	/tmp/._license_
						fi
						_license_old=`cat  /tmp/._license_|grep "$_license_"|grep -v "grep"`
						if [ "$_license_old" == "" ];then
							#配置代理地址
							# up_dir="/storage/cyber/etc/net"
							# local_tmp_file="/tmp/ip.conf"
							# cp $default_ip_conf  $local_tmp_file 
							# echo "eth0 	192.168.$loop.$_ip_d 	255.255.255.0"|tr -d '\r' >>$local_tmp_file
							# sh auto_ssh.sh scp_up $default_ip $default_gapa_passwd $local_tmp_file $up_dir 2>&1 >>/dev/null
							# rm -rf $local_tmp_file
							if [ $_ip_d = 4 ];then
								sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/default/a\\eth0 	192.168.'$loop'.'$(($_ip_d-1))' 	255.255.255.0' /usr/gap/etc/net/ip.conf" 2>&1 >>/dev/null
							else
								sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/default/a\\eth0 	192.168.'$loop'.'$_ip_d' 	255.255.255.0' /usr/gap/etc/net/ip.conf" 2>&1 >>/dev/null
							fi
							#配置文件同步任务
							cp $default_task_conf  $local_tmp_disk
							echo "$loop 	192.168.$loop.$_ip_d 	$_file_port 	10240 	0"|tr -d '\r' >>$local_tmp_disk
							sh auto_ssh.sh scp_up $default_ip $default_gapa_passwd $local_tmp_disk $up_dir_disk 2>&1 >>/dev/null
							rm -rf $local_tmp_disk
							#缓存配置
							# up_dir="/usr/gap/etc/disk/task.conf"
							# local_tmp_file="/tmp/task.conf"
							# cp $default_task_cache  $local_tmp_file 
							# echo "$loop FILESYNC 10240"|tr -d '\r' >>$local_tmp_file
							sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/task/a\\'$loop' FILESYNC 10240' /usr/gap/etc/disk/task.conf" 2>&1 >>/dev/null
							# sh auto_ssh.sh scp_up $default_ip $default_gapa_passwd $local_tmp_file $up_dir 2>&1 >>/dev/null
							# rm -rf $local_tmp_file
							#配置防火墙规则为全局允许
							up_dir="/usr/gap/etc/firewall/filesync_access.conf"
							sh auto_ssh.sh ssh $default_ip $default_gapa_passwd "sed -i '/^action=/caction=ACCEPT' /usr/gap/etc/firewall/*.conf" 2>&1 >>/dev/null
							echo $loop=$_license_
							echo $loop=$_license_ >>/tmp/._license_ && _id=$(($_id+1))
							sh auto_ssh.sh ssh $default_ip $default_gapa_passwd 'shutdown -h now && ifconfig man down'  2>&1 >>/dev/null
							#sleep $default_ping
					        unset _license_ _license_old  default_ip _check_id up_dir_disk local_tmp_disk name
							#echo "Please replace the next device and connect it to management!!!(This $name config ok)"
						else
							echo "$loop=$_license_ 已存在" && _id=$(($_id+1))
							sh auto_ssh.sh ssh $default_ip $default_gapa_passwd 'shutdown -h now && ifconfig man down'  2>&1 >>/dev/null
							#sleep $default_ping
						fi
					fi
				done
							echo "Please replace the next device and connect it to management!!!(Device configuration Success)"
			done
			;;
		recv_conf)
				sh Tmp_fsync.sh add_Tmp_fsync 2>&1  >>/dev/null #安装发送/接收客户端软件
				#echo $2
				_add_ip eth0 $run_number 4 #ip NIC C D {192.168.C.D}
				 default_config=$default_recv_conf
        	      for ((loop=1;loop<=$run_number;loop++));
					do
						if [ ! -x "$recvdir$loop" ]; then #判断文件夹是否存在
				    	  mkdir  -p $recvdir$loop
				          _recv_file_dir=$recvdir$loop/`echo $2|awk -F_ '{print $1}'`_file
						  _recv_config="$recvdir$loop/filesync.conf"
						  _recv_log="$recvdir$loop"
						  mkdir  -p $_recv_file_dir  && cp $default_soft $recvdir$loop/fsync-lin
						#[system]系统配置
						sed -e '/^mode=/cmode=recv' $default_config |tr -d '\r'  >$_recv_config #替换指定行内容(mode=recv) 
						sed -i '/^backlist=/cbacklist=1' $_recv_config |tr -d '\r' #替指backlist内容(0不保存列表；1保存文件列表) 
						sed -i '/^service=/cservice=recv'$loop'' $_recv_config |tr -d '\r' #替指service内容 
						#[authority]认证配置
						#[log]日志配置
						_start=`grep -rn "path" $_recv_config|sed -n 1p |awk -F: '{print $1}'|tr -d '\r'`
						sed -i ''$_start'c\path='$_recv_log''  $_recv_config |tr -d '\r' #替换log中path行内容(path=$recvdir$loop) 
						#[task]任务配置
						sed -i '/^id=/cid='$loop''  $_recv_config |tr -d '\r' #替指id内容(id=$loop) 
						sed -i '/^desc=/cdesc=recv-task-'$loop''  $_recv_config |tr -d '\r' #替指desc内容(desc=recv-task-$loop) 
						sed -i '/^ip=/cip=192.168.'$loop'.4'  $_recv_config |tr -d '\r' #替换ip行内容(ip=192.168.$loop.4) 
						sed -i '/^port=/cport='$(($loop+16100))''  $_recv_config |tr -d '\r' #替换指port内容(port=161$loop) 
						#sed -i '/^synctype=/csynctype=del'  $_send_config |tr -d '\r' #替换synctype内容(synctype=copy|del) 
						_start=`grep -rn "path" $_recv_config|sed -n 2p |awk -F: '{print $1}'|tr -d '\r'`
						sed -i ''$_start'c\path='$_recv_file_dir''  $_recv_config |tr -d '\r' #替换task中path行内容(path=$recvdir$loop/recv_file) 
						sed -i '/^tmpnaming=/ctmpnaming=off'  $_recv_config |tr -d '\r' #替换指tmpnaming内容(off关闭|) 
						sed -i '/^dupfile=/cdupfile=repl'  $_recv_config |tr -d '\r' #替换指dupfile内容(repl替换|mark时间戳标记) 
						fi
					done 
			;;
		*)
			echo $0  $1 "{send_conf(1发送端配置)|gap_conf(2/3网闸内外网端配置|recv_conf(4接收端配置)}"
			;;
	esac
	;;
	default) #恢复设备默认配置
	echo $1
		for ((loop=1;loop<=$run_number;loop++));
		do 
			default_ping=10
			while [ 1 ]
			do
				ping_ck p2 $default_ping $default_gapa_ip 2>&1 >>/dev/null 
				_pa=$?  #检查连接设备内网是否正常：$?=3表示正常,4表示错误
				ping_ck p2 $default_ping $default_gapb_ip 2>&1 >>/dev/null 
				_pb=$?  #检查连接设备外网是否正常：$?=3表示正常,4表示错误
				_sum=$(($_pa+$_pb))
				if [ "$_sum" == "6" ];then
					break
				fi
			done
			_id=1 && id=1
				until (( $_id >2 ))
				do
					if [ $_id = 1 ];then
						sh auto_ssh.sh ssh 192.168.0.201 $default_gapa_passwd 'sh /usr/gap/scripts/sys_renew.sh && sleep 2 && shutdown -h now && ifconfig man down'  2>&1 >>/dev/nul
						echo "第$loop台设备A板恢复默认出厂配置成功！！！"
						_id=$(($_id+1))
					elif [ $_id = 2 ];then
						sh auto_ssh.sh ssh 192.168.0.202 $default_gapb_passwd 'sh /usr/gap/scripts/sys_renew.sh && sleep 2 && shutdown -h now && ifconfig man down'  2>&1 >>/dev/nul
						echo "第$loop台设备B板恢复默认出厂配置成功！！！"
						_id=$(($_id+1))
					fi
			  done
		done
		
	;;
	service) #启停服务
	 echo $1
	  case $2 in 
		   start_send|start_recv)#启动专用文件同步发送端|接收端
		   if [ $2 == start_send ];then
				_service=$senddir
			else
				_service=$recvdir
			fi
		     for ((loop=1;loop<=$run_number;loop++))
		      do
				#echo "$_service$dir$loop/fsync-lin &"
				 $_service$loop/fsync-lin &
			 done
	       ;;
		   stop_send|stop_recv)#停止发送端|接收端服务
                kill -9 `ps aux|grep -v grep|grep fsync-lin|awk '{print $2}'`   
	       ;;
	   esac 
	;;
	file) #生成待发文件 or 接收检查文件
	echo $1
	  case $2 in
			add_file)#发送端添加文件
				echo "add file"
				for ((i=1;i<=$touch_number;i++))
				   do	
					   if [ $i = 1 ];then
							dd if=/dev/zero of=/.$i.$file_type bs=1M  count=$file_size  >>/dev/null  2>&1
					   elif [ $i = $touch_number ];then
							rm -rf /.$i.$file_type
					   fi
					   for ((loop=1;loop<=$run_number;loop++));
					   do
						   if [ "$check_md5" == "on" ];then #判断是否开启MD5检查
							 echo $loop-$i >>/.1.$file_type
							_name=`md5sum /.1.$file_type|awk '{print $1}'`
						   fi
						   cp /.1.$file_type  $senddir$loop/send_file/$loop\_$i-$_name.$file_type  #&& sync
						   #echo "`date +%F====%T`	$list	Delete	ok!!!" 
						   echo "`date +%F====%T`	$loop-$i	"$loop"_$i-$_name.$file_type	Create	ok!!!"
					   done
						usage=`df -k |grep $_disk_drive|grep lv|grep -v grep  `
						if [ "$usage" == "" ];then
							usage=`df -k |grep $_disk_drive|awk '{print $5}'|tr -d '%'`
						else
						    usage=`df -k |grep $_disk_drive |grep -v iso |grep -v lv  |awk '{print $4}'|tr -d '%'`
						fi
						# if [ ! $usage ];then
							# echo "Check to see if the alert is empty!!!"
							# exit
						# fi
						if [ $usage -ge $_disk_alert ];then
							for ((loop=1;loop<=$run_number;loop++));
								do
								check_file  $senddir$loop/send_file   AA
							done
							sync
						fi
				   done
			;;
			check_file)#接收端检查文件并删除
			   echo "check_file"
			   	while [ 1 ]
				  do 
					sleep $_sleep
						usage=`df -k |grep $_disk_drive|grep lv|grep -v grep  `
						if [ "$usage" == "" ];then
							usage=`df -k |grep $_disk_drive|awk '{print $5}'|tr -d '%'`
						else
						    usage=`df -k |grep $_disk_drive |grep -v iso |grep -v lv  |awk '{print $4}'|tr -d '%'`
						fi
					# if [ ! $usage ];then
						# echo "Check to see if the alert is empty!!!"
						# exit
					# fi
					if [ $usage -ge $_disk_alert ];then
						for ((loop=1;loop<=$run_number;loop++));
						do
						check_file  $recvdir$loop/recv_file  BB
						done
						sync
					fi
				done
			;;
			*)
			 echo $0  file  "{add_file(添加file)|default(恢复默认配置)|check_file(检查文件)}"
			;;
		esac
	 ;;
 esac
}
###############################################
touch_number=9999999999999999999999999999999  #生产文件总数
_disk_drive=home    #监控目录(df可查看到的目录)
check_md5=off       #是否开启文件MD5检验(on/off)
default_gapa_ip=192.168.0.201 default_gapa_passwd=Cyber@XA\#2009
default_gapb_ip=192.168.0.202 default_gapb_passwd=Cyber@XA\#2009
run_number=2  #客户端数目
default_path=/home/loongson    #默认客户端目录
##############################################################################
_disk_alert=75  	#设置硬盘警戒值,超出将进行删除文件动作
_sleep=100            #检查硬盘警戒值间隙时间(单位秒)
check_md5=off       #是否开启文件MD5检验(on/off)
file_size=1			#生成文件大小(单位MB)
file_type=rar		#生成文件类型
task_number=1 #客户端运行任务数目
default_soft="/tmp/.fsync/.fsync-lin"
default_send_conf="/tmp/.fsync/.fsync_send.conf"
default_recv_conf="/tmp/.fsync/.fsync_recv.conf"
default_ip_conf="/tmp/.fsync/.ip.conf"
default_task_conf="/tmp/.fsync/.task.conf"
default_task_cache="/tmp/.fsync/.cache.task.conf"
default_firewall_conf="/tmp/.fsync/.filesync_access.conf"
senddir="$default_path/send"
recvdir="$default_path/recv"
###############################################
#stability_test  add gap_conf  #配置设备eth0文件同步规则及eth1代理策略 ok
#stability_test  add send_conf  #配置文件同步发送端 ok
#stability_test  add recv_conf  #配置文件同步接收端 ok
#stability_test  service start_send  #启动文件同步发送客户端 ok
#stability_test  service start_recv  #启动文件同步接收客户端 ok
#stability_test  service stop_send   #停止文件同步发送客户端  ok
#stability_test  service stop_recv   #停止文件同步接收客户端 ok
#stability_test  file add_file 		 #生成文件并移动至待发送目录(开启源端删除) 
#stability_test  file check_file 	 #检查接受目录文件并清除接收完成的正确文件
stability_test  default 









